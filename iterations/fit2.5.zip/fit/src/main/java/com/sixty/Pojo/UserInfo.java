package com.sixty.Pojo;
import lombok.Data;

@Data
public class UserInfo {
    private String username;
    private float balance=0;
    private  double[][] bmiGroup;

}
