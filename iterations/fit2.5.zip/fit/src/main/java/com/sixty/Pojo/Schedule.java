package com.sixty.Pojo;
import lombok.Data;

@Data
public class Schedule {

    private String username;
    private String trainerName;
    private String demand;
    private String date;
    private String time;
    private String type;
    private String orderTime;
    private String state;

}
