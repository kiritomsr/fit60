package com.sixty.Pojo;
import lombok.Data;

@Data
public class Trainer {

    private String id;
    private String username;
    private String password;
    private String phone;
    private String email;
    private String sex;
    private String photoUrl;
}
